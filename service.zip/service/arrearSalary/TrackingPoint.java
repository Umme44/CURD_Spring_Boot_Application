package com.bits.hr.service.arrearSalary;

import com.bits.hr.domain.enumeration.Month;

public class TrackingPoint {

    Month month;
    int year;
}
