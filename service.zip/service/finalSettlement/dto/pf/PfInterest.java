package com.bits.hr.service.finalSettlement.dto.pf;

import java.util.Objects;
import lombok.Data;

@Data
public class PfInterest {

    private double ownInterest;
    private double companyInterest;
}
