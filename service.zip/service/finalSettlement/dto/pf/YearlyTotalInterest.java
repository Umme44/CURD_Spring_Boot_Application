package com.bits.hr.service.finalSettlement.dto.pf;

import lombok.Data;

@Data
public class YearlyTotalInterest {

    private double totalEmployeeInterestInYear;
    private double totalEmployerInterestInYear;
}
