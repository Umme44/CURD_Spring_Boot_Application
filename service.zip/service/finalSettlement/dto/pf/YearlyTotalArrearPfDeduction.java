package com.bits.hr.service.finalSettlement.dto.pf;

import lombok.Data;

@Data
public class YearlyTotalArrearPfDeduction {

    private double totalEmployeeArrearPfDeduction;
    private double totalEmployerArrearPfDeduction;
}
