package com.bits.hr.service.finalSettlement.dto.pf;

import lombok.Data;

@Data
public class YearlyTotalContribution {

    private double totalEmployeeContributionInYear;
    private double totalEmployerContributionInYear;
}
