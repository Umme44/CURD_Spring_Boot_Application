package com.bits.hr.service.finalSettlement.dto;

import lombok.Data;

@Data
public class AbsentDaysAdjustment {

    int numberOfDays;
    double amountToDeduct;
}
