package com.bits.hr.service.finalSettlement.dto.salary;

import lombok.Data;

@Data
public class SalaryPayable {

    double salaryPayable = 0;
    String salaryPayableRemarks = "";
}
