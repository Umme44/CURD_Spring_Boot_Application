package com.bits.hr.service.finalSettlement.dto.salary;

import lombok.Data;

@Data
public class SalaryDeduction {

    // private double noticePay;
    // private double noticePayDays;
    private double pfDeduction;
    private double hafDeduction;
    private double excessPhoneBill;
    private double otherDeduction;
    // private double absentDaysAdjustment;
}
