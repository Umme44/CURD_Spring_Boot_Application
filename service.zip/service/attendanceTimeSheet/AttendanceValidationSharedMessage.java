package com.bits.hr.service.attendanceTimeSheet;

public class AttendanceValidationSharedMessage {}
