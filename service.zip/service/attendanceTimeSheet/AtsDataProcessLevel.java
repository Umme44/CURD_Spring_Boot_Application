package com.bits.hr.service.attendanceTimeSheet;

public enum AtsDataProcessLevel {
    MINIMAL,
    FULL_FEATURED_USER,
    FULL_FEATURED_ADMIN,
}
