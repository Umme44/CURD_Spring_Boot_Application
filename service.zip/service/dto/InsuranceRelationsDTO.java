package com.bits.hr.service.dto;

import java.util.List;
import lombok.Data;

@Data
public class InsuranceRelationsDTO {

    private List<String> relations;
}
