package com.bits.hr.service.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FileImportDetailsDTO {

    String title;
    boolean uploadSuccess;
}
