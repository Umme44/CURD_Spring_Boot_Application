package com.bits.hr.service.dto;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;

@Data
public class AllowanceNameDTO {

    private String allowance01Name;
    private String allowance02Name;
    private String allowance03Name;
    private String allowance04Name;
    private String allowance05Name;
    private String allowance06Name;
}
