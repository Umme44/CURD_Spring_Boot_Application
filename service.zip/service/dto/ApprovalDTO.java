package com.bits.hr.service.dto;

import java.util.List;
import lombok.Data;

@Data
public class ApprovalDTO {

    List<Long> listOfIds;
}
