package com.bits.hr.service.dto;

import lombok.Data;

@Data
public class DepartmentItemsDTO {

    private long departmentId;
    private String departmentName;
    private long totalItems;
}
