package com.bits.hr.service.communication.email;

public class EmailAddressConfig {

    public static final String TEAM_BRAC_IT_EMAIL = "all@bracits.com";
    public static final String TEAM_HR_EMAIL = "hr@bracits.com";
}
