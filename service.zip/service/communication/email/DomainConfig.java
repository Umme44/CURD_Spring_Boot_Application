package com.bits.hr.service.communication.email;

public class DomainConfig {

    public static final String BASE_URL = "https://rongdhonu.bracits.com";
}
