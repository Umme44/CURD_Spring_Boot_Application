package com.bits.hr.service.fileOperations.pathBuilder;

public enum PathCategory {
    TMP,
    TEMPLATES,
    NOMINEE,
    ID_CARD,
    OFFER,
    INSURANCE,
    TAX_ACKNOWLEDGEMENT_RECEIPT,
    ORGANIZATION,
    PROCUREMENT,
    EMPLOYEE_DOCUMENTS,
    EMPLOYEE_DOCUMENTS_TMP
}
