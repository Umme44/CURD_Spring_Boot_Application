package com.bits.hr.service.config.DTO;

public enum AttendanceRegularizationMethod {
    FIXED_DAY,
    FULL_MONTH,
}
