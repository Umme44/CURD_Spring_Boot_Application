package com.bits.hr.service.event;

public enum EventType {
    CREATED,
    UPDATED,
    APPROVED,
    REJECTED,
}
