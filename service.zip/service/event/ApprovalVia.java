package com.bits.hr.service.event;

public enum ApprovalVia {
    HR,
    LM,
}
