/**
 * Spring Data JPA repositories.
 */
package com.bits.hr.repository;
