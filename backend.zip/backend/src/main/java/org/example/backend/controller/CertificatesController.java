package org.example.backend.controller;

import org.example.backend.entity.Certificates;
import org.example.backend.repository.CertificatesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.security.cert.Certificate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/")
public class CertificatesController {

    @Autowired
    public CertificatesRepository certificatesRepository;

    //Get all certificates
    @GetMapping("/certificates")
    public List<Certificates> getAllCertificates(){
        return certificatesRepository.findAll();
    }

    //Create certificates
    @PostMapping("/create_certificates")
    public Certificates createCertificate(@RequestBody  Certificates certificates){
        return certificatesRepository.save(certificates);
    }

    //get certificates by id
    @GetMapping("/certificates/{id}")
    public ResponseEntity<Certificates> getCertificateById(@PathVariable Long id){
        Certificates certificates = certificatesRepository.findById(id)
                .orElseThrow();
        return ResponseEntity.ok(certificates);

    }

    //update certificates
    @PutMapping("certificates/{id}")
    public ResponseEntity<Certificates> updateCertificates(@PathVariable Long id, @RequestBody Certificates certificatesDetails){
        Certificates certificates  = certificatesRepository.findById(id)
                .orElseThrow();
//        certificates.setId(certificatesDetails.getId());
        certificates.setDescription(certificatesDetails.getDescription());
        certificates.setCompletionDate(certificatesDetails.getCompletionDate());
        certificates.setEnrolledDate(certificatesDetails.getEnrolledDate());
        certificates.setImageUrl(certificatesDetails.getImageUrl());
        certificates.setPin(certificatesDetails.getPin());
        certificates.setIs_Expired(certificatesDetails.isIs_Expired());
        certificates.setExpiredDate(certificatesDetails.getExpiredDate());


        Certificates updateCertificates = certificatesRepository.save(certificates);
        return ResponseEntity.ok(updateCertificates);

    }

    //Delete certificatse
    @DeleteMapping("/certificates/{id}")
    public ResponseEntity<Map<String ,Boolean>> deleteCertificate(@PathVariable Long id){
        Certificates certificates = certificatesRepository.findById(id)
                .orElseThrow();
        certificatesRepository.delete(certificates);
        Map<String ,Boolean> response = new HashMap<>();
        response.put(" deleted ",Boolean.TRUE);
        return ResponseEntity.ok(response);

    }





}
