package org.example.backend.entity;


import jakarta.persistence.*;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "certificates")
@org.hibernate.annotations.Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class Certificates {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator", sequenceName = "sequence_generator", allocationSize = 1)
    @Column(name = "id")
    private Long id;

    @Column(name = "PIN")
    private Integer pin;

    @Override
    public String toString() {
        return "Certificates{" +
                "id=" + id +
                ", pin=" + pin +
                ", imageUrl='" + imageUrl + '\'' +
                ", description='" + description + '\'' +
                ", enrolledDate=" + enrolledDate +
                ", completionDate=" + completionDate +
                ", expiredDate=" + expiredDate +
                ", is_Expired=" + is_Expired +
                ", materials_Learned=" + materials_Learned +
                '}';
    }

    @Column(name = "imageUrl")
    private String imageUrl;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getPin() {
        return pin;
    }

    public void setPin(Integer pin) {
        this.pin = pin;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getEnrolledDate() {
        return enrolledDate;
    }

    public void setEnrolledDate(LocalDate enrolledDate) {
        this.enrolledDate = enrolledDate;
    }

    public LocalDate getCompletionDate() {
        return completionDate;
    }

    public void setCompletionDate(LocalDate completionDate) {
        this.completionDate = completionDate;
    }

    public LocalDate getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(LocalDate expiredDate) {
        this.expiredDate = expiredDate;
    }

    public boolean isIs_Expired() {
        return is_Expired;
    }

    public void setIs_Expired(boolean is_Expired) {
        this.is_Expired = is_Expired;
    }

    public List<String> getMaterials_Learned() {
        return materials_Learned;
    }

    public void setMaterials_Learned(List<String> materials_Learned) {
        this.materials_Learned = materials_Learned;
    }

    @Column(name = "description")
    private String description;

    @Column(name = "enrolledDate")
    private LocalDate enrolledDate;

    @Column(name = "completionDate")
    private LocalDate completionDate;

    @Column(name = "expiredDate")
    private LocalDate expiredDate;

    @Column(name = "is_Expired")
    private boolean is_Expired;

    @ElementCollection
    @Column(name = "materials_Learned")
    @CollectionTable(name = "materials_Learned", joinColumns = @JoinColumn(name = "entity_id"))
    private List<String> materials_Learned;


}
